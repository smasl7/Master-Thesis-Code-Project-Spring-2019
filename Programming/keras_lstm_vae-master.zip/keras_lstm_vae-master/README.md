# readme.

Keras implementation of LSTM Variational Autoencoder. 

##### References
    - [Building Autoencoders in Keras](https://blog.keras.io/building-autoencoders-in-keras.html)
    - [Generating sentences from a continuous space](https://arxiv.org/abs/1511.06349)

# License
MIT 
